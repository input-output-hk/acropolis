create function user_search(uname text)
    returns TABLE(usename name, passwd text)
    security definer
    language sql
as
$$
  SELECT usename, passwd FROM pg_shadow WHERE usename=uname;
$$;

alter function user_search(text) owner to postgres;

