create view pg_stat_statements
            (userid, dbid, toplevel, queryid, query, plans, total_plan_time, min_plan_time, max_plan_time,
             mean_plan_time, stddev_plan_time, calls, total_exec_time, min_exec_time, max_exec_time, mean_exec_time,
             stddev_exec_time, rows, shared_blks_hit, shared_blks_read, shared_blks_dirtied, shared_blks_written,
             local_blks_hit, local_blks_read, local_blks_dirtied, local_blks_written, temp_blks_read, temp_blks_written,
             blk_read_time, blk_write_time, wal_records, wal_fpi, wal_bytes)
as
SELECT pg_stat_statements.userid,
       pg_stat_statements.dbid,
       pg_stat_statements.toplevel,
       pg_stat_statements.queryid,
       pg_stat_statements.query,
       pg_stat_statements.plans,
       pg_stat_statements.total_plan_time,
       pg_stat_statements.min_plan_time,
       pg_stat_statements.max_plan_time,
       pg_stat_statements.mean_plan_time,
       pg_stat_statements.stddev_plan_time,
       pg_stat_statements.calls,
       pg_stat_statements.total_exec_time,
       pg_stat_statements.min_exec_time,
       pg_stat_statements.max_exec_time,
       pg_stat_statements.mean_exec_time,
       pg_stat_statements.stddev_exec_time,
       pg_stat_statements.rows,
       pg_stat_statements.shared_blks_hit,
       pg_stat_statements.shared_blks_read,
       pg_stat_statements.shared_blks_dirtied,
       pg_stat_statements.shared_blks_written,
       pg_stat_statements.local_blks_hit,
       pg_stat_statements.local_blks_read,
       pg_stat_statements.local_blks_dirtied,
       pg_stat_statements.local_blks_written,
       pg_stat_statements.temp_blks_read,
       pg_stat_statements.temp_blks_written,
       pg_stat_statements.blk_read_time,
       pg_stat_statements.blk_write_time,
       pg_stat_statements.wal_records,
       pg_stat_statements.wal_fpi,
       pg_stat_statements.wal_bytes
FROM pg_stat_statements(true) pg_stat_statements(userid, dbid, toplevel, queryid, query, plans, total_plan_time,
                                                 min_plan_time, max_plan_time, mean_plan_time, stddev_plan_time, calls,
                                                 total_exec_time, min_exec_time, max_exec_time, mean_exec_time,
                                                 stddev_exec_time, rows, shared_blks_hit, shared_blks_read,
                                                 shared_blks_dirtied, shared_blks_written, local_blks_hit,
                                                 local_blks_read, local_blks_dirtied, local_blks_written,
                                                 temp_blks_read, temp_blks_written, blk_read_time, blk_write_time,
                                                 wal_records, wal_fpi, wal_bytes);

alter table pg_stat_statements
    owner to postgres;

grant select on pg_stat_statements to public;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1uc7rpt0n40qv2ulygp2;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1t4agj8cvvad86dq5pf3r;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync160kww9m5pfp60gum020c;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync14hknu4uefsf703ht5qv5;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync104wzthz9pg4fg02rpv09;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync10zgujwdgtdez7yq6s7kd;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1c448v72tk5dw37h744zv;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1qxflajkh7v2xnytxsprr;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync14qaulug2lj2cvm88fcr;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1gaepgwqav0c72fxl0xwr;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1xvr8tdxnf58k9hx6r3r6;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync17uzlpx745gxcv3f0ue8u;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync12ggdtuvq063hglfhrjd3;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1sefmlv2set2zcm77p6t;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1qsc87thmatsy77q8w0cd;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync15c5j5ny7zzgskw7f936j;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1jrjwmcfck6p4xtteelsy;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1ahttxmd45mfq7tj2rh5y;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1xn5na5y8ffhjkd2xc7t;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1xpxcqupu726qa7rwa2ww;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1vs4l2t9zvm39zf4wlqdy;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1dftfrj8xzanl0plf5trf;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1pz6y34dums5jkvdjst8;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1lcesha2x8g9mkthrehp;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1v3mfyfxp8eqaug8ude6;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1kv647hr77aj7v0nalwq;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1tlcladt9z4cjxd7lpv5;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1n7pef0du8vp2ke8t66fn;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1l5lv2tq58c77spa3an5;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1wjrqx4ry3vyk203m3v2;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1gjecv859vdx26km68wx;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1w8dxwulr5rwtn0mrddhl;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1frx6vg90xjf95x49km2;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1ttq60rsffxmkj2jenqnm;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1fdlrsyn9gw9gjklgp6us;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync17v0k60gka93662tu0nxw;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1aehc6j2drsq0gmmjw64p;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync17gnqj6ct8gha99uwsamu;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1kgq4z9z3atfcwwq0tv6m;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1xt7zs9myw3vuuxq4m5l;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1udg4j6zgfl6kzd36cvp;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync17dkjguzu2urd8kmu8e3s;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync18kkc8yysuvh3kx473cy;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync16cwnnn7ultnjunnh3m3;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1mz8c2nn4p339c26gnhqy;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1adw7v8g3n549clq7jlvc;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1xh6e3aym85wgsuvgqnc;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1kp5fv8x2lp9mxw70w8v;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1654yk0aps80cws9aydu;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1dv6lsnh6aky75ufns77;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1fngzz6q8k5xj7qadw5ps;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1lzhxuz2cpf72q7ed3qa;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1jwrwlg9scsjm2hulxl06;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync19r4n8leq2hj7qrjap75d;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1m5q42drdxqsfxme8mvjn;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1804rsdfzzv9djfufwwt;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1e5fl2xvlnju7xplxvm2z;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1jwhcc9whjqqqny86jt4d;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync15fpvkuf8hanxn6l4ckyf;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync10acvadmunyhwcnq8g2a;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1ch5547znnpm27atm2m25;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1ss3kjwrg5ezxh5kuhnct;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1yys0suejn7aptl2cs46w;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1hdr0gahl7zse60gq8vaj;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync12sf4wnhhxjvtwkk7yds7;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync15hk2ffez462ec5qv4tx8;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1jmynvaka67zdzgmj39k9;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1jwujp9wwj9mw5fd2ra3;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync138qeu40u2az64tj6xeyn;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync138wy53knqptw6f4j9d2v;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync18heca9qx3krt2cg8m7gt;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1khtmlmftk8lak3hjza9;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1hdmrgy53j9y6f3d0g3jc;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1sd2x26wj86x0fh6g8yjm;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1vsw5n7tvsptftxya6zgj;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1zku0a3fyry0lcxxtp3ja;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1y03dlq0cduuj2npyhxp;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1etrqw5hsfpsyxzd4t77f;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1wvuc558l8yynxxsc35m3;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1uugk48fwk4dsplxxlwr4;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync15m65593aexaaqs75pecq;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1jggk0455e2gnv9ha4ch;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1thae7cel4xt2xmk6wca;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync182uus9595az6slsse7d;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1skww36rswhlm2prgpaa;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync18va76cpuj2hjuws5ucj7;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync19u0z5t5uj9c5ltupkd7x;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1g9aplcp65uk62mh5m2nd;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1cmznndxplyqwkheejuh;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1p7qk4k47l6gfva9p2zcx;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1gr80c3grz8u327w0rva;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1w2qph3fwgdzlshe7hs0e;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1pxhusx0v2yd4068mhd0e;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1eq82drddyyv06z4zf6kr;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1tf83hl06hllzjxpyhjz;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dbsync1u82hjz4jr0xxxav590x;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync15tvq6nejnnhpwgw4584r;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1hxquthdnljffaet2hhnh;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1jl5heyrfda0g5tk57krf;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync1t40cgu9vpq72ukguvsd0;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync14xxkjsm8650upy38u5dp;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements to dmtr_dbsync16ut45hcy9w5pknrvd8kn;

grant select on pg_stat_statements to pgbouncer;

grant select on pg_stat_statements to dbsync13jhf238ftuffkda79k5;

grant select on pg_stat_statements to dbsync1dv7c4ly0u7gzu4zshnk;

grant select on pg_stat_statements to dmtr_blockfrost;

grant select on pg_stat_statements to dbsync1z7epq4edujjsy5awjzr;

grant select on pg_stat_statements to dbsync1tjayfzp34cj6wlv0qaq;

grant select on pg_stat_statements to dbsync1t39v796tz57svhfna66;

grant select on pg_stat_statements to dbsync158mkl9f2l0dg5nddnf3;

grant select on pg_stat_statements to dbsync1a6clq4chkl0fztmetx2;

grant select on pg_stat_statements to dbsync1sl72ler2y2yxsuef53r;

grant select on pg_stat_statements to dbsync1p5msttx5azm9u7gfukw;

grant select on pg_stat_statements to dbsync1tlmne97nry30k3uelmv;

grant select on pg_stat_statements to dbsync1ld4mjqrky094ka0m28c;

grant select on pg_stat_statements to dbsync10k4zpr55fl20u9s2xtu;

grant select on pg_stat_statements to dbsync1jwx473mp28mvc2qz2f3;

grant select on pg_stat_statements to dbsync10jarkq839ywtvh742nc;

grant select on pg_stat_statements to dbsync1398zqnxkh27m7k3wjkc;

grant select on pg_stat_statements to dbsync1n9mcjrd2pngzyn7jhgz;

grant select on pg_stat_statements to dbsync1t4vhkg35kenju2vzr3p;

grant select on pg_stat_statements to dbsync1p4zl3fjteen6kzhp70t;

grant select on pg_stat_statements to dbsync1gntrv0xtlcer7pwtjsa;

grant select on pg_stat_statements to dbsync16erzd3zdv8rycpw735a;

grant select on pg_stat_statements to dbsync1pgkuyehg7x0r7vkxkv7;

grant select on pg_stat_statements to dbsync1yay7nn45wydz20736jh;

grant select on pg_stat_statements to dbsync1qwyxqnt56vg42hnlggy;

grant select on pg_stat_statements to dbsync19n05tk9nnm6xjzqxetn;

grant select on pg_stat_statements to dbsync1yjmvnt7kj7lxsudarjj;

grant select on pg_stat_statements to dbsync1c5s8m2w39u58krkppah;

grant select on pg_stat_statements to dbsync1fc2ctwlz7tj67x67v25;

grant select on pg_stat_statements to dbsync12jke95aganc4c0sgw69;

grant select on pg_stat_statements to dbsync1pl2c30r8y96sckr6uvg;

grant select on pg_stat_statements to dbsync1jm8s37j94wz2cadp86l;

grant select on pg_stat_statements to dbsync1wr4vkh7ry84lkx2gvc7;

grant select on pg_stat_statements to dbsync1he40jg2vfuhxvg9l4ce;

grant select on pg_stat_statements to dbsync1lhuse4nhw225cq63dlu;

grant select on pg_stat_statements to dbsync1j3c5d3hrjc7e2krgsrr;

grant select on pg_stat_statements to dbsync124px7yuc7x7rxx57rk5;

grant select on pg_stat_statements to dbsync144tc3mk34uff2nt7uzd;

grant select on pg_stat_statements to dbsync13hf7m5a4jsd2zm04f7t;

grant select on pg_stat_statements to dbsync18rswtydf03u77m3chr9;

grant select on pg_stat_statements to dbsync1q63759t2dcgqj3x4mln;

grant select on pg_stat_statements to dbsync16k0trqqsmssc5s5cjz3;

grant select on pg_stat_statements to dbsync14tq8fgcsscpjkm9pek3;

grant select on pg_stat_statements to dbsync1tdkyg5y9jndkjwrr7yt;

grant select on pg_stat_statements to dbsync1uukpyum2whm3cqu6702;

grant select on pg_stat_statements to dbsync1grp3qzaj4gsnxaqkvrr;

grant select on pg_stat_statements to dbsync13lmas5gstjl5yjpn6ea;

grant select on pg_stat_statements to dbsync1p4v44eq6xd3mjldy3cl;

grant select on pg_stat_statements to dbsync1829wxxnzqvcaj5zrjqt;

grant select on pg_stat_statements to dbsync166s6srwghkr6unqdhup;

grant select on pg_stat_statements to dbsync1l7f5csmkl5xq2e69fm8;

grant select on pg_stat_statements to dbsync1cxt2jjedrgzl273qeqr;

grant select on pg_stat_statements to dbsync1zktq42lelljr6mpvqh8;

grant select on pg_stat_statements to dbsync1xuh0gez0p9fvj6fw64m;

grant select on pg_stat_statements to dbsync15a032v7e8se6wadk7c2;

grant select on pg_stat_statements to dbsync1zrd65yfzfsjk7zt98j8;

grant select on pg_stat_statements to dbsync1udqf8j088xs3vaqzqh3;

grant select on pg_stat_statements to dbsync1428tn2jvzhzjck5j6dp;

grant select on pg_stat_statements to dbsync1hcdkjz049sh3v7a6l4g;

grant select on pg_stat_statements to dbsync16d809a8w5ccuzkkn7sy;

grant select on pg_stat_statements to dbsync158jtw83wjzglkfx6tcv;

grant select on pg_stat_statements to dbsync1ejm9ftxvern2z6jp303;

grant select on pg_stat_statements to dbsync19qxpdtnsvvv35cxknqd;

grant select on pg_stat_statements to dbsync1d0553gx5ensmw4g53lp;

grant select on pg_stat_statements to dbsync1yvdr2wdv9p3k56dqxas;

grant select on pg_stat_statements to dbsync1cnsc4v7l9kkm7dxegxp;

grant select on pg_stat_statements to dbsync16ngq7xy6yg3ejydnw5x;

grant select on pg_stat_statements to dbsync1e4jpmr82qp06uk9zcx0;

grant select on pg_stat_statements to dbsync1hzmt4hjs4ucfk9fwtqu;

grant select on pg_stat_statements to dbsync1mh6zk0pth0pnsxy6sq5;

grant select on pg_stat_statements to dbsync1evtaad398lz3vash7q6;

grant select on pg_stat_statements to dbsync1azc3w4w0pttmcpp2uj2;

grant select on pg_stat_statements to dbsync1ylwv8cr87t38gjy7ujs;

grant select on pg_stat_statements to dbsync1x4w35ftqms20kutf5a9;

grant select on pg_stat_statements to dbsync1q8qdkz9umwrf6xj3xzm;

grant select on pg_stat_statements to dbsync16fj98pmnm77sjfumark;

grant select on pg_stat_statements to dbsync1j9x5tql5pm68zcyamnl;

